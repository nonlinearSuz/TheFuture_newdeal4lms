package kr.happyjob.study.admmtd.model;

public class ResourceModel {

	public int getItem_no() {
		return item_no;
	}
	public void setItem_no(int item_no) {
		this.item_no = item_no;
	}
	public int getRoom_no() {
		return room_no;
	}
	public void setRoom_no(int room_no) {
		this.room_no = room_no;
	}
	public String getItem_nm() {
		return item_nm;
	}
	public void setItem_nm(String item_nm) {
		this.item_nm = item_nm;
	}
	public int getItem_vol() {
		return item_vol;
	}
	public void setItem_vol(int item_vol) {
		this.item_vol = item_vol;
	}
	public String getItem_etc() {
		return item_etc;
	}
	public void setItem_etc(String item_etc) {
		this.item_etc = item_etc;
	}
	
	public String getRm_name() {
		return rm_name;
	}
	public void setRm_name(String rm_name) {
		this.rm_name = rm_name;
	}
	
	
	
	

	
	
	private String rm_name;
	private int item_no;
	private int room_no;
	private String item_nm;
	private int item_vol;
	private String item_etc;


	
}
	


