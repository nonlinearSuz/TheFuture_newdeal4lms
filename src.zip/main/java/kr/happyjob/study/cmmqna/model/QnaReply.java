package kr.happyjob.study.cmmqna.model;

import lombok.Data;

@Data
public class QnaReply {
	
	private int qna_no; 
	public int getQna_no() {
		return qna_no;
	}
	public void setQna_no(int qna_no) {
		this.qna_no = qna_no;
	}
	public int getRpy_no() {
		return rpy_no;
	}
	public void setRpy_no(int rpy_no) {
		this.rpy_no = rpy_no;
	}
	public String getRpy_contents() {
		return rpy_contents;
	}
	public void setRpy_contents(String rpy_contents) {
		this.rpy_contents = rpy_contents;
	}
	public String getEnr_date() {
		return enr_date;
	}
	public void setEnr_date(String enr_date) {
		this.enr_date = enr_date;
	}
	public String getEnr_user() {
		return enr_user;
	}
	public void setEnr_user(String enr_user) {
		this.enr_user = enr_user;
	}
	public String getUpd_date() {
		return upd_date;
	}
	public void setUpd_date(String upd_date) {
		this.upd_date = upd_date;
	}
	public String getUpd_user() {
		return upd_user;
	}
	public void setUpd_user(String upd_user) {
		this.upd_user = upd_user;
	}
	public int getCategory_no() {
		return category_no;
	}
	public void setCategory_no(int category_no) {
		this.category_no = category_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLoginID() {
		return loginID;
	}
	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}
	
	
	private int rpy_no; //Q_댓글 번호
	private String rpy_contents; //댓글 내용
	private String enr_date; //작성일
	private String enr_user; //작성자
	private String upd_date; //수정일
	private String upd_user; //수정자
	private int category_no; //카테고리 번호
	
	private String name;
	private String loginID;
	
}
