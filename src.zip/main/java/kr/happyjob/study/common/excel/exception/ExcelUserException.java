package kr.happyjob.study.common.excel.exception;

public class ExcelUserException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4727764049759881089L;

	public ExcelUserException() {
		
	}
	
	public ExcelUserException(String msg) {
		super(msg);
	}
}
