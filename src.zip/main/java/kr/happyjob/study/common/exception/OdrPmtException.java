package kr.happyjob.study.common.exception;

public class OdrPmtException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5321429711356225366L;

	public OdrPmtException() {
		
	}
	
	public OdrPmtException(String msg) {
		super(msg);
	}
}
