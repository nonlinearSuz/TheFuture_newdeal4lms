package kr.happyjob.study.consupport.dao;

import java.util.List;





import java.util.Map;

import org.springframework.stereotype.Repository;


import kr.happyjob.study.consupport.model.ConSupportBModel;
import kr.happyjob.study.consupport.model.NameListModel;



public interface ConSupportBDao {

	/** 프로젝트 목록 조회 */
	public List<ConSupportBModel> listConSupportB(Map<String, Object> paramMap) throws Exception;

	
	/** 프로젝트 목록 카운트 조회 */
	public int countListConSupportB(Map<String, Object> paramMap) throws Exception;
	
	
	/** 이름 목록 조회 */
	public List<NameListModel> listNameList(Map<String, Object> paramMap);
	
	
	/** 이름 목록 카운트 조회 */
	public int countListlistNameList(Map<String, Object> paramMap) throws Exception;
	
	
	
	
	
	
	
	
	
}
