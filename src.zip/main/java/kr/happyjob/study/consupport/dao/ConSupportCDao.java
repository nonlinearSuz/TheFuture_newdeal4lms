package kr.happyjob.study.consupport.dao;

import java.util.List;




import java.util.Map;

import org.springframework.stereotype.Repository;

import kr.happyjob.study.consupport.model.ConSupportCModel;



public interface ConSupportCDao {

	/** 프로젝트 목록 조회 */
	public List<ConSupportCModel> listConSupportC(Map<String, Object> paramMap) throws Exception;

	
	/** 프로젝트 목록 카운트 조회 */
	public int countListConSupportC(Map<String, Object> paramMap) throws Exception;
	
}
