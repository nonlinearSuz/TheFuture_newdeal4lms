package kr.happyjob.study.consupport.model;

import java.util.Date;

public class ConSupportBModel {

	//프로젝트 번호
	private int pro_no;
	//프로젝트 이름		
	private String pro_name;
	//시작 날짜
	private String pro_appstart;
	//종료 날짜
	private String pro_append;
	// 지원자 수
	private int pro_pcnt;
	
	public int getPro_no() {
		return pro_no;
	}
	public void setPro_no(int pro_no) {
		this.pro_no = pro_no;
	}
	public String getPro_name() {
		return pro_name;
	}
	public void setPro_name(String pro_name) {
		this.pro_name = pro_name;
	}
	public String getPro_appstart() {
		return pro_appstart;
	}
	public void setPro_appstart(String pro_appstart) {
		this.pro_appstart = pro_appstart;
	}
	public String getPro_append() {
		return pro_append;
	}
	public void setPro_append(String pro_append) {
		this.pro_append = pro_append;
	}
	public int getPro_pcnt() {
		return pro_pcnt;
	}
	public void setPro_pcnt(int pro_pcnt) {
		this.pro_pcnt = pro_pcnt;
	}

	
	
	
	
	
	
	

}
