package kr.happyjob.study.dashboard.dao;

import java.util.List;
import java.util.Map;

import kr.happyjob.study.dashboard.model.DeliveryBuyerModel;

public interface DashboardDlmDao {
	
	List<DeliveryBuyerModel> deliveryBuyerList(Map<String, Object> paramMap);

}
