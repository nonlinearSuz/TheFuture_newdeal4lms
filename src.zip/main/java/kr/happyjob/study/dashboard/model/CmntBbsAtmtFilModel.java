package kr.happyjob.study.dashboard.model;

public class CmntBbsAtmtFilModel {

	private String bbs_id;
	private String snm;
	private String atmt_fil_lgc_fil_nm;
	private String atmt_fil_psc_fil_nm;
	private String fil_siz;
	private String fil_ets;
	/**
	 * @return the bbs_id
	 */
	public String getBbs_id() {
		return bbs_id;
	}
	/**
	 * @param bbs_id the bbs_id to set
	 */
	public void setBbs_id(String bbs_id) {
		this.bbs_id = bbs_id;
	}
	/**
	 * @return the snm
	 */
	public String getSnm() {
		return snm;
	}
	/**
	 * @param snm the snm to set
	 */
	public void setSnm(String snm) {
		this.snm = snm;
	}
	/**
	 * @return the atmt_fil_lgc_fil_nm
	 */
	public String getAtmt_fil_lgc_fil_nm() {
		return atmt_fil_lgc_fil_nm;
	}
	/**
	 * @param atmt_fil_lgc_fil_nm the atmt_fil_lgc_fil_nm to set
	 */
	public void setAtmt_fil_lgc_fil_nm(String atmt_fil_lgc_fil_nm) {
		this.atmt_fil_lgc_fil_nm = atmt_fil_lgc_fil_nm;
	}
	/**
	 * @return the atmt_fil_psc_fil_nm
	 */
	public String getAtmt_fil_psc_fil_nm() {
		return atmt_fil_psc_fil_nm;
	}
	/**
	 * @param atmt_fil_psc_fil_nm the atmt_fil_psc_fil_nm to set
	 */
	public void setAtmt_fil_psc_fil_nm(String atmt_fil_psc_fil_nm) {
		this.atmt_fil_psc_fil_nm = atmt_fil_psc_fil_nm;
	}
	/**
	 * @return the fil_siz
	 */
	public String getFil_siz() {
		return fil_siz;
	}
	/**
	 * @param fil_siz the fil_siz to set
	 */
	public void setFil_siz(String fil_siz) {
		this.fil_siz = fil_siz;
	}
	/**
	 * @return the fil_ets
	 */
	public String getFil_ets() {
		return fil_ets;
	}
	/**
	 * @param fil_ets the fil_ets to set
	 */
	public void setFil_ets(String fil_ets) {
		this.fil_ets = fil_ets;
	}
	
	
}
