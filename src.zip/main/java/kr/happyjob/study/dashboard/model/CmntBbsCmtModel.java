package kr.happyjob.study.dashboard.model;

public class CmntBbsCmtModel {
	// 코멘트 ID
	private String cmt_id;
	// BBS_ID
	private String bbs_id;
	// 시스템 로그인 유저
	private String usr_sst_id;
	// 로그인 유저명
	private String usr_nm;
	// 코멘트 내용
	private String cmt_cnt;
	// 최초 등록 일시
	private String fst_rgst_dtt;
	// 최초 등록자 시스템 ID
	private String fst_rgst_sst_id;
	// 최종 수정 일시
	private String fnl_mdfd_dtt;
	// 최종 수정자 시스템 ID
	private String fnl_mdfr_sst_id;
	/**
	 * @return the cmt_id
	 */
	public String getCmt_id() {
		return cmt_id;
	}
	/**
	 * @param cmt_id the cmt_id to set
	 */
	public void setCmt_id(String cmt_id) {
		this.cmt_id = cmt_id;
	}
	/**
	 * @return the bbs_id
	 */
	public String getBbs_id() {
		return bbs_id;
	}
	/**
	 * @param bbs_id the bbs_id to set
	 */
	public void setBbs_id(String bbs_id) {
		this.bbs_id = bbs_id;
	}
	/**
	 * @return the usr_sst_id
	 */
	public String getUsr_sst_id() {
		return usr_sst_id;
	}
	/**
	 * @param usr_sst_id the usr_sst_id to set
	 */
	public void setUsr_sst_id(String usr_sst_id) {
		this.usr_sst_id = usr_sst_id;
	}
	/**
	 * @return the usr_nm
	 */
	public String getUsr_nm() {
		return usr_nm;
	}
	/**
	 * @param usr_nm the usr_nm to set
	 */
	public void setUsr_nm(String usr_nm) {
		this.usr_nm = usr_nm;
	}
	/**
	 * @return the cmt_cnt
	 */
	public String getCmt_cnt() {
		return cmt_cnt;
	}
	/**
	 * @param cmt_cnt the cmt_cnt to set
	 */
	public void setCmt_cnt(String cmt_cnt) {
		this.cmt_cnt = cmt_cnt;
	}
	/**
	 * @return the fst_rgst_dtt
	 */
	public String getFst_rgst_dtt() {
		return fst_rgst_dtt;
	}
	/**
	 * @param fst_rgst_dtt the fst_rgst_dtt to set
	 */
	public void setFst_rgst_dtt(String fst_rgst_dtt) {
		this.fst_rgst_dtt = fst_rgst_dtt;
	}
	/**
	 * @return the fst_rgst_sst_id
	 */
	public String getFst_rgst_sst_id() {
		return fst_rgst_sst_id;
	}
	/**
	 * @param fst_rgst_sst_id the fst_rgst_sst_id to set
	 */
	public void setFst_rgst_sst_id(String fst_rgst_sst_id) {
		this.fst_rgst_sst_id = fst_rgst_sst_id;
	}
	/**
	 * @return the fnl_mdfd_dtt
	 */
	public String getFnl_mdfd_dtt() {
		return fnl_mdfd_dtt;
	}
	/**
	 * @param fnl_mdfd_dtt the fnl_mdfd_dtt to set
	 */
	public void setFnl_mdfd_dtt(String fnl_mdfd_dtt) {
		this.fnl_mdfd_dtt = fnl_mdfd_dtt;
	}
	/**
	 * @return the fnl_mdfr_sst_id
	 */
	public String getFnl_mdfr_sst_id() {
		return fnl_mdfr_sst_id;
	}
	/**
	 * @param fnl_mdfr_sst_id the fnl_mdfr_sst_id to set
	 */
	public void setFnl_mdfr_sst_id(String fnl_mdfr_sst_id) {
		this.fnl_mdfr_sst_id = fnl_mdfr_sst_id;
	}
}
