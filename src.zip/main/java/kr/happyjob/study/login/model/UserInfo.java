package kr.happyjob.study.login.model;

public class UserInfo {
	
		
	public String getLoginID() {
		return loginID;
	}
	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUser_gender() {
		return user_gender;
	}
	public void setUser_gender(String user_gender) {
		this.user_gender = user_gender;
	}
	public String getUser_birth() {
		return user_birth;
	}
	public void setUser_birth(String user_birth) {
		this.user_birth = user_birth;
	}
	public String getUser_email() {
		return user_email;
	}
	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}
	public String getUser_post() {
		return user_post;
	}
	public void setUser_post(String user_post) {
		this.user_post = user_post;
	}
	public String getUser_addr() {
		return user_addr;
	}
	public void setUser_addr(String user_addr) {
		this.user_addr = user_addr;
	}
	public String getAddr_detail() {
		return addr_detail;
	}
	public void setAddr_detail(String addr_detail) {
		this.addr_detail = addr_detail;
	}
	public String getUser_ph() {
		return user_ph;
	}
	public void setUser_ph(String user_ph) {
		this.user_ph = user_ph;
	}
	public String getFile_nm() {
		return file_nm;
	}
	public void setFile_nm(String file_nm) {
		this.file_nm = file_nm;
	}
	public String getLec_yn() {
		return lec_yn;
	}
	public void setLec_yn(String lec_yn) {
		this.lec_yn = lec_yn;
	}
	public String getUser_active() {
		return user_active;
	}
	public void setUser_active(String user_active) {
		this.user_active = user_active;
	}
	public String getUser_type() {
		return user_type;
	}
	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}
	public String getFile_no() {
		return file_no;
	}
	public void setFile_no(String file_no) {
		this.file_no = file_no;
	}
	
	
	private String loginID;
	private String password;
	private String name;
	private String user_gender;
	private String user_birth;
	private String user_email;
	private String user_post;
	private String user_addr;
	private String addr_detail;
	private String user_ph;
	private String file_nm;
	private String lec_yn;
	private String user_active;
	private String user_type;
	private String file_no;
	
	
	
	
}
