package kr.happyjob.study.rsvrem.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateExercise {
	

	public static void main(String[] args) throws Exception{
		
		SimpleDateFormat sDate = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		System.out.println(sDate.format(new Date()));

		Date a = new Date();
		System.out.println("a==" +a);
		SimpleDateFormat s2Date = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		Date date = s2Date.parse("2023-06-30 11:00:00");
		System.out.println(date);
		System.out.println(a.after(date));
		
	}
}
