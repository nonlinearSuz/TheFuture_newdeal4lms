package kr.happyjob.study.supass.model;
//주석
public class ExistModel {
	private int success; // 1 -존재 0- 존재X

}
