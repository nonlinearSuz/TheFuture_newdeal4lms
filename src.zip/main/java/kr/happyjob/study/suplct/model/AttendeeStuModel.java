 package kr.happyjob.study.suplct.model;

public class AttendeeStuModel {
//주석
	public String getLoginID() {
		return loginID;
	}
	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getLec_no() {
		return lec_no;
	}
	public void setLec_no(int lec_no) {
		this.lec_no = lec_no;
	}
	public String getLec_name() {
		return lec_name;
	}
	public void setLec_name(String lec_name) {
		this.lec_name = lec_name;
	}
	
	public String getAcc_yn() {
		return acc_yn;
	}
	public void setAcc_yn(String acc_yn) {
		this.acc_yn = acc_yn;
	}
	public String getDrop_yn() {
		return drop_yn;
	}
	public void setDrop_yn(String drop_yn) {
		this.drop_yn = drop_yn;
	}
	public String getTot_score() {
		return tot_score;
	}
	public void setTot_score(String tot_score) {
		this.tot_score = tot_score;
	}

	public String getUser_birth() {
		return user_birth;
	}
	public void setUser_birth(String user_birth) {
		this.user_birth = user_birth;
	}
	public String getUser_hp() {
		return user_hp;
	}
	public void setUser_hp(String user_hp) {
		this.user_hp = user_hp;
	}

	

	private String user_birth;  				/*수강자 생일*/
	private String user_hp;                    /*수강자 전화번호*/
	private String loginID;					/* user 로그인 아이디 */
	private String name;						/* user 이름 */
	private int lec_no;						/* 강의 번호 */
	private String lec_name;					/* 강의명 */
	private String acc_yn;						/* 강의 수강 승인 상태 */
	private String drop_yn;					/*과락 여부 */
	private String tot_score; 				   /*최종 시험점수*/
	

	

	
	
	
}
	
