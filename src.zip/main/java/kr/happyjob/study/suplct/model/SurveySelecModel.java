 package kr.happyjob.study.suplct.model;

public class SurveySelecModel {

	public int getSv_no() {
		return sv_no;
	}
	public void setSv_no(int sv_no) {
		this.sv_no = sv_no;
	}
	public String getSv_name() {
		return sv_name;
	}
	public void setSv_name(String sv_name) {
		this.sv_name = sv_name;
	}
	public String getSv_writer() {
		return sv_writer;
	}
	public void setSv_writer(String sv_writer) {
		this.sv_writer = sv_writer;
	}
	
	int sv_no; 				 /* 설문지 번호 */
	String sv_name;			 /* 설문지 이름 */
	String sv_writer;		 /* 등록자 */
	//주석
	
	
}
	
