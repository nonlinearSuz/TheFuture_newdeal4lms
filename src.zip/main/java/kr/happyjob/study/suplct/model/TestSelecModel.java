 package kr.happyjob.study.suplct.model;

public class TestSelecModel {

	
	public int getTest_no() {
		return test_no;
	}
	public void setTest_no(int test_no) {
		this.test_no = test_no;
	}
	public String getTest_name() {
		return test_name;
	}
	public void setTest_name(String test_name) {
		this.test_name = test_name;
	}
	
	int test_no;   //시험번호 
	String test_name; //시험 이름
	//주석
	
}
	
