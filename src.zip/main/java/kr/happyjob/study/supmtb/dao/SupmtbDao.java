package kr.happyjob.study.supmtb.dao;

import java.util.List;
import java.util.Map;

import kr.happyjob.study.supmtb.model.MyTableModel;

public interface SupmtbDao {
	List<MyTableModel> lecTimeList(Map<String, Object> paramMap)throws Exception;

}
