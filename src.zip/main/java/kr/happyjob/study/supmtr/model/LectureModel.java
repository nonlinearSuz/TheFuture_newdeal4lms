package kr.happyjob.study.supmtr.model;

public class LectureModel {

	   //주석!!
	private int lec_no;
	private String lec_name;
	private String lec_prof;
	//private String loginID;
	
/*	public String getLoginID() {
		return loginID;
	}
	public void setLoginID(String loginID) {
		this.loginID = loginID;}*/
	
	public int getLec_no() {
		return lec_no;
	}
	public void setLec_no(int lec_no) {
		this.lec_no = lec_no;
	}
	public String getLec_name() {
		return lec_name;
	}
	public void setLec_name(String lec_name) {
		this.lec_name = lec_name;
	}
	public String getLec_prof() {
		return lec_prof;
	}
	public void setLec_prof(String lec_prof) {
		this.lec_prof = lec_prof;
	}
	@Override
	public String toString() {
		return "LectureModel [lec_no=" + lec_no + ", lec_name=" + lec_name + ", lec_prof=" + lec_prof + "]";
	}


	
	
}
