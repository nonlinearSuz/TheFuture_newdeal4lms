package kr.happyjob.study.system.dao;

import kr.happyjob.study.system.model.comcombo;

import java.util.List;
import java.util.Map;

public interface ComnComboDao {


	/** 로그인 사용자 강의목록 조회 */
	public List<comcombo> selectlecbyuserlist(Map<String, Object> paramMap) throws Exception;
	
    /** 사용자  목록 조회 */
    public List<comcombo> selectuserlist(Map<String, Object> paramMap) throws Exception;
  
    /** 시험  목록 조회 */
    public List<comcombo> selecttestlist(Map<String, Object> paramMap) throws Exception;
    
    /** 설문  목록 조회 */
    public List<comcombo> selectsurveylist(Map<String, Object> paramMap) throws Exception;
}
