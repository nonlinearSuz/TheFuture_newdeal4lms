package kr.happyjob.study.system.model;

public class ComnCodUtilModel {

	private String grp_cod;
	
	private String dtl_cod;
	
	private String dtl_cod_nm;
	
	private String tmp_fld_01;
	
	private String tmp_fld_02;
	
	private String tmp_fld_03;
	
	private String tmp_fld_04;

	/**
	 * @return the grp_cod
	 */
	public String getGrp_cod() {
		return grp_cod;
	}

	/**
	 * @param grp_cod the grp_cod to set
	 */
	public void setGrp_cod(String grp_cod) {
		this.grp_cod = grp_cod;
	}

	/**
	 * @return the dtl_cod
	 */
	public String getDtl_cod() {
		return dtl_cod;
	}

	/**
	 * @param dtl_cod the dtl_cod to set
	 */
	public void setDtl_cod(String dtl_cod) {
		this.dtl_cod = dtl_cod;
	}

	/**
	 * @return the dtl_cod_nm
	 */
	public String getDtl_cod_nm() {
		return dtl_cod_nm;
	}

	/**
	 * @param dtl_cod_nm the dtl_cod_nm to set
	 */
	public void setDtl_cod_nm(String dtl_cod_nm) {
		this.dtl_cod_nm = dtl_cod_nm;
	}

	/**
	 * @return the tmp_fld_01
	 */
	public String getTmp_fld_01() {
		return tmp_fld_01;
	}

	/**
	 * @param tmp_fld_01 the tmp_fld_01 to set
	 */
	public void setTmp_fld_01(String tmp_fld_01) {
		this.tmp_fld_01 = tmp_fld_01;
	}

	/**
	 * @return the tmp_fld_02
	 */
	public String getTmp_fld_02() {
		return tmp_fld_02;
	}

	/**
	 * @param tmp_fld_02 the tmp_fld_02 to set
	 */
	public void setTmp_fld_02(String tmp_fld_02) {
		this.tmp_fld_02 = tmp_fld_02;
	}

	/**
	 * @return the tmp_fld_03
	 */
	public String getTmp_fld_03() {
		return tmp_fld_03;
	}

	/**
	 * @param tmp_fld_03 the tmp_fld_03 to set
	 */
	public void setTmp_fld_03(String tmp_fld_03) {
		this.tmp_fld_03 = tmp_fld_03;
	}

	/**
	 * @return the tmp_fld_04
	 */
	public String getTmp_fld_04() {
		return tmp_fld_04;
	}

	/**
	 * @param tmp_fld_04 the tmp_fld_04 to set
	 */
	public void setTmp_fld_04(String tmp_fld_04) {
		this.tmp_fld_04 = tmp_fld_04;
	}
	
	
}
