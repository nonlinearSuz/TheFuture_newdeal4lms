package kr.happyjob.study.system.model;

public class MnuMgrLstModel {
	
	private String mnu_id;

	/**
	 * @return the mnu_id
	 */
	public String getMnu_id() {
		return mnu_id;
	}

	/**
	 * @param mnu_id the mnu_id to set
	 */
	public void setMnu_id(String mnu_id) {
		this.mnu_id = mnu_id;
	}



}
