$(document).ready(function() {

	// 중양정렬
	
	var docH = $(document).height();
	var idH = $('#wrap_login').height();
	var marginTop = docH/2-idH/2;
	
	$('#wrap_login').css('margin-top', marginTop);
	

});


